import { useState, useEffect, useRef } from "react";
import axios from "axios";

const chatbotColors = {
  user: "bg-orange-500 text-white",
  bot: "bg-gray-100 text-gray-900 border border-gray-200",
};

const messageAlign = {
  user: "justify-end",
  bot: "justify-start",
};

const Chatbot = ({ userId = "user123" }) => {
  const [messages, setMessages] = useState([]);
  const [type, setType] = useState("query");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  // Load conversation history
  const loadMessages = async () => {
    try {
      const res = await axios.get(`/api/chat/${userId}`);
      setMessages(res.data);
    } catch (err) {
      setMessages([
        {
          message: "Sorry, couldn't load your previous messages.",
          reply: null,
          sender: "bot",
        },
      ]);
    }
  };

  useEffect(() => {
    loadMessages();
  }, []);

  // Scroll to the bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Send a new message
  const send = async () => {
    if (!input.trim() || loading) return;
    setLoading(true);

    // Optimistic UI: Show user message immediately
    const userMsg = { message: input, reply: null, sender: "user" };
    setMessages((msgs) => [...msgs, userMsg]);

    try {
      const res = await axios.post("/api/chat", { userId, type, message: input });
      // Show bot reply
      setMessages((msgs) => [
        ...msgs.slice(0, -1), // Remove optimistic user message
        userMsg,
        { message: input, reply: res.data.reply, sender: "bot" },
      ]);
    } catch {
      setMessages((msgs) => [
        ...msgs.slice(0, -1),
        userMsg,
        { message: input, reply: "Sorry, something went wrong. Please try again.", sender: "bot" },
      ]);
    } finally {
      setInput("");
      setLoading(false);
    }
  };

  // Handle enter key
  const handleKeyDown = (e) => {
    if (e.key === "Enter") send();
  };

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col h-[80vh] rounded-3xl shadow-2xl bg-gradient-to-br from-orange-50 via-white to-orange-100 border border-orange-100 relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center px-6 py-4 bg-white/80 border-b border-orange-100 sticky top-0 z-10">
        <img src="/swiggy-logo.svg" alt="" className="w-8 h-8 mr-3" />
        <span className="text-xl font-bold text-orange-600 tracking-tight">CanteenBot</span>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-2 bg-gradient-to-b from-white to-orange-50">
        {messages.length === 0 && (
          <div className="text-center text-gray-400 mt-16">Start a conversation with CanteenBot!</div>
        )}
        {messages.map((msg, i) => {
          // User message bubble
          const showUser =
            i === 0 || messages[i - 1].sender !== "user"
              ? (
                  <div key={`user-${i}`} className={`flex ${messageAlign.user} mb-1`}>
                    <div className={`max-w-[70%] px-4 py-2 rounded-2xl shadow ${chatbotColors.user}`}>
                      {msg.message}
                    </div>
                  </div>
                )
              : null;

          // Bot message bubble (show only if there is a reply)
          const showBot =
            msg.reply ? (
              <div key={`bot-${i}`} className={`flex ${messageAlign.bot} mb-1`}>
                <div className={`max-w-[70%] px-4 py-2 rounded-2xl shadow ${chatbotColors.bot}`}>
                  {msg.reply}
                </div>
              </div>
            ) : null;

          return (
            <div key={i}>
              {showUser}
              {showBot}
            </div>
          );
        })}
        {loading && (
          <div className="flex justify-start mb-1">
            <div className="max-w-[70%] px-4 py-2 rounded-2xl shadow bg-gray-100 text-gray-400 border border-gray-200 animate-pulse">
              Typing...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="px-4 py-4 bg-white/90 border-t border-orange-100 flex items-center gap-2 sticky bottom-0">
        <select
          className="border border-orange-200 rounded-lg px-2 py-2 text-sm text-orange-700 bg-orange-50 focus:outline-none"
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="query">Query</option>
          <option value="complaint">Complaint</option>
          <option value="feedback">Feedback</option>
        </select>
        <input
          className="flex-1 border border-orange-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-orange-200 bg-white"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          disabled={loading}
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          className={`ml-2 rounded-full px-5 py-2 font-semibold shadow transition 
            ${loading || !input.trim()
              ? "bg-orange-300 text-white cursor-not-allowed"
              : "bg-orange-500 hover:bg-orange-600 text-white"
            }`}
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default Chatbot;