import { Route, Switch, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import Home from "@/pages/home";
import Menu from "@/pages/menu";
import AuthPage from "@/pages/auth-page";
import VoiceOrder from "@/pages/voice-order";
import DietAnalysis from "@/pages/diet-analysis";
import TrackOrder from "@/pages/track-order";
import Offers from "@/pages/offers";
import QRMenu from "@/pages/qr-menu";
import ChatbotPage from "@/pages/chatbot-page";
import MenuRecommendations from "@/pages/menu-recommendations";
import CartPage from "@/pages/cart-page";
import AboutUs from "./pages/about";
import Contact from "./pages/Contact";
import NotFound from "@/pages/not-found";

// ProtectedRoute component
function ProtectedRoute({ component: Component, ...rest }) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // If not authenticated, redirect to /auth
  if (!user) {
    setLocation("/auth");
    return null;
  }

  // Otherwise, render the protected component
  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/auth" component={AuthPage} />
      <Route path="/about" component={AboutUs} />
      <Route path="/contact" component={Contact} />

      {/* Protected Routes */}
      <ProtectedRoute path="/" component={Home} />
      <ProtectedRoute path="/menu" component={Menu} />
      <ProtectedRoute path="/voice-order" component={VoiceOrder} />
      <ProtectedRoute path="/diet-analysis" component={DietAnalysis} />
      <ProtectedRoute path="/track-order" component={TrackOrder} />
      <ProtectedRoute path="/offers" component={Offers} />
      <ProtectedRoute path="/qr-menu" component={QRMenu} />
      <ProtectedRoute path="/chatbot" component={ChatbotPage} />
      <ProtectedRoute path="/menu-recommendations" component={MenuRecommendations} />
      <ProtectedRoute path="/cart" component={CartPage} />

      {/* Catch-all */}
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}