import { useQueryClient } from "@tanstack/react-query";
import { useState, useEffect, useCallback } from "react";
import "./CartPage.css";

const formatPrice = (amt) => `₹${amt.toFixed(2)}`;
const keyId = "rzp_test_GSJiWRjhbGJDup";

const loadRazorpayScript = (src) => {
  return new Promise((resolve) => {
    if (document.querySelector(`script[src="${src}"]`)) return resolve(true);
    const script = document.createElement("script");
    script.src = src;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

export default function CartPage() {
  const queryClient = useQueryClient();
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setCart(queryClient.getQueryData(["/cart-items"]) || []);
    const cache = queryClient.getQueryCache();
    const unsubscribe = cache.subscribe(() => {
      setCart(queryClient.getQueryData(["/cart-items"]) || []);
    });
    return () => {
      if (typeof unsubscribe === "function") unsubscribe();
      else if (unsubscribe && typeof unsubscribe.unsubscribe === "function") unsubscribe.unsubscribe();
    };
  }, [queryClient]);

  const updateQty = (id, delta) => {
    setCart((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(item.quantity + delta, 1) }
          : item
      )
    );
    // You should also update cart in queryClient/server here as needed
  };

  const removeItem = (id) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
    // You should also update cart in queryClient/server here as needed
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const delivery = total ? 40 : 0;
  const gst = total * 0.05;
  const toPay = total + delivery + gst;

  const goMenu = () => {
    window.location.href = "/menu";
  };

  const handleCheckout = useCallback(async () => {
    setLoading(true);
    const scriptLoaded = await loadRazorpayScript("https://checkout.razorpay.com/v1/checkout.js");
    if (!scriptLoaded) {
      alert("Razorpay SDK failed to load. Are you online?");
      setLoading(false);
      return;
    }
    let tries = 0;
    while (typeof window.Razorpay === "undefined" && tries < 10) {
      await new Promise((r) => setTimeout(r, 150));
      tries++;
    }
    if (typeof window.Razorpay === "undefined") {
      alert("Razorpay SDK not available on window. Please reload the page.");
      setLoading(false);
      return;
    }
    if (total <= 0) {
      alert("Cart total must be greater than zero.");
      setLoading(false);
      return;
    }
    const options = {
      key: keyId,
      amount: Math.round(toPay * 100),
      currency: "INR",
      name: "Food Order",
      description: "Thank you for your order!",
      handler: (response) => {
        setLoading(false);
        alert("Payment successful! Payment ID: " + response.razorpay_payment_id);
      },
      prefill: {
        name: "vasanthapandiyan R",
        email: "vasanthudesh@gmail.com",
        contact: "8778362367",
      },
      theme: { color: "#2094f3" }, // Your blue accent
      modal: {
        ondismiss: () => {
          setLoading(false);
          alert("Payment cancelled or closed.");
        },
      },
    };
    try {
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (e) {
      alert("Oops! Something went wrong while initiating payment.");
      setLoading(false);
    }
  }, [total, toPay]);

  if (!cart.length) {
    return (
      <div className="swiggy-cart-empty">
        <img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto/empty_cart_yfxml0" alt="Empty Cart" />
        <div className="swiggy-cart-empty-title">Your cart is empty</div>
        <div className="swiggy-cart-empty-desc">Good food is always cooking! Go ahead, order some yummy items from the menu.</div>
        <button className="swiggy-cart-empty-btn" onClick={goMenu}>SEE MENU</button>
      </div>
    );
  }

  return (
    <div className="swiggy-cart-root">
      <div className="swiggy-cart-container">
        {/* Cart Items Section */}
        <div className="swiggy-cart-left">
          <h2 className="swiggy-cart-title">Cart</h2>
          <div className="swiggy-cart-items">
            {cart.map((item) => (
              <div className="swiggy-cart-item" key={item.id}>
                <div className="swiggy-cart-item-dot">
                  {item.isVeg !== false ? (
                    <span className="veg-dot" title="Veg"></span>
                  ) : (
                    <span className="nonveg-dot" title="Non-Veg"></span>
                  )}
                </div>
                <div className="swiggy-cart-item-details">
                  <div className="swiggy-cart-item-name">{item.name}</div>
                  <div className="swiggy-cart-item-price">{formatPrice(item.price)}</div>
                </div>
                <div className="swiggy-cart-item-actions">
                  <button
                    aria-label="Decrease"
                    className="swiggy-cart-qty-btn"
                    onClick={() => updateQty(item.id, -1)}
                  >−</button>
                  <span className="swiggy-cart-qty">{item.quantity}</span>
                  <button
                    aria-label="Increase"
                    className="swiggy-cart-qty-btn"
                    onClick={() => updateQty(item.id, 1)}
                  >+</button>
                </div>
                <div className="swiggy-cart-item-total">
                  {formatPrice(item.price * item.quantity)}
                </div>
                <button
                  className="swiggy-cart-remove"
                  title="Remove item"
                  onClick={() => removeItem(item.id)}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
        {/* Bill Summary Section */}
        <div className="swiggy-cart-right">
          <div className="swiggy-cart-summary">
            <div className="swiggy-cart-summary-title">Bill Details</div>
            <div className="swiggy-cart-summary-row">
              <span>Item Total</span>
              <span>{formatPrice(total)}</span>
            </div>
            <div className="swiggy-cart-summary-row">
              <span>Delivery Fee</span>
              <span>{formatPrice(delivery)}</span>
            </div>
            <div className="swiggy-cart-summary-row">
              <span>GST & Charges</span>
              <span>{formatPrice(gst)}</span>
            </div>
            <hr className="swiggy-cart-summary-divider"/>
            <div className="swiggy-cart-summary-row swiggy-cart-summary-pay">
              <span>TO PAY</span>
              <span>{formatPrice(toPay)}</span>
            </div>
            <button
              className={`swiggy-cart-pay-btn${loading ? " loading" : ""}`}
              onClick={handleCheckout}
              disabled={loading}
            >
              {loading ? (
                <span>
                  <span className="swiggy-cart-spinner"></span>
                  Processing...
                </span>
              ) : (
                <>Pay {formatPrice(toPay)}</>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}