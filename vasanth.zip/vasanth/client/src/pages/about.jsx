import React, { useEffect, useState } from "react";
import "./about.css";
import logImg from "@/asset/images/log.jpg"; 

const stats = [
  { label: "Happy Users", value: 500, suffix: "+" },
  { label: "Dishes Served Daily", value: 150, suffix: "+" },
  { label: "Order Accuracy", value: 99, suffix: "%" },
  { label: "AI Chatbot Support", value: 24, suffix: "/7" },
];

function AnimatedStat({ value, suffix, duration = 1000 }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = parseInt(value, 10);
    if (start === end) return;
    let incrementTime = Math.max(10, Math.floor(duration / end));
    let current = start;
    const timer = setInterval(() => {
      current += 1;
      setCount(current);
      if (current === end) clearInterval(timer);
    }, incrementTime);
    return () => clearInterval(timer);
  }, [value, duration]);

  return (
    <span className="swiggy-about-stat-number">
      {count}
      {suffix}
    </span>
  );
}

function Feature({ icon, title, text }) {
  return (
    <div className="swiggy-about-feature">
      <span className="swiggy-about-feature-icon">{icon}</span>
      <div>
        <h3>{title}</h3>
        <p>{text}</p>
      </div>
    </div>
  );
}

export default function AboutModern() {
  return (
    <main className="swiggy-about-main">
      <section className="swiggy-about-hero">
        <div className="swiggy-about-hero-content">
          <img
            src={logImg} 
            alt="Smart AI Canteen"
            className="swiggy-about-logo"
          />
          <h1>
            <span>Smart AI Canteen</span>
            <br />
            <span className="swiggy-about-highlight">Management System</span>
          </h1>
          <p>
            <b>Experience the future of campus dining.</b> Order food, track nutrition, and enjoy a seamless, eco-friendly canteen—powered by AI, designed for you.
          </p>
          <div className="swiggy-about-cta">
            <a href="/contact" className="swiggy-about-btn">Contact Us</a>
            <a href="#features" className="swiggy-about-link">See Features ↓</a>
          </div>
        </div>
        <div className="swiggy-about-stats">
          {stats.map((stat) => (
            <div className="swiggy-about-stat" key={stat.label}>
              <AnimatedStat value={stat.value} suffix={stat.suffix} duration={stat.label === "Happy Users" ? 1200 : 800} />
              <div className="swiggy-about-stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>
      <section className="swiggy-about-features-grid" id="features">
        <Feature
          icon="📱"
          title="Instant Mobile Orders"
          text="Scan QR, order and pay—your food, your way, in seconds."
        />
        <Feature
          icon="🤖"
          title="24/7 AI Chat"
          text="Get instant answers and support, any time, from our smart chatbot."
        />
        <Feature
          icon="🥗"
          title="Personalized Meals"
          text="AI-powered recommendations for healthy, delicious dishes you'll love."
        />
        <Feature
          icon="⏰"
          title="Live Order Tracking"
          text="Know exactly when your food is ready—real-time updates from kitchen to pickup."
        />
        <Feature
          icon="💳"
          title="Seamless Digital Payments"
          text="Pay securely with UPI, cards, or wallets—no cash, no hassle."
        />
        <Feature
          icon="🌱"
          title="Eco-Friendly Dining"
          text="Paperless menus, green packaging, and waste-conscious service."
        />
      </section>
      <section className="swiggy-about-mission">
        <h2>Our Mission</h2>
        <p>
          To make every campus meal healthy, fast, and delightful—combining smart technology with sustainability and convenience.
        </p>
      </section>
      <section className="swiggy-about-vision">
        <h2>Our Vision</h2>
        <p>
          We empower communities with intelligent, eco-friendly canteen solutions—where food, technology, and wellbeing come together for a better future.
        </p>
      </section>
      <footer className="swiggy-about-footer">
        <p>
          Want to know more or partner with us? <a href="/contact" className="swiggy-about-footer-link">Contact Smart AI Canteen</a>
        </p>
      </footer>
    </main>
  );
}