import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import bannerImg from "@/asset/images/banner.jpg"; 

import { z } from "zod";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { insertUserSchema } from "@shared/schema";
import logImg from "@/asset/images/log.jpg"; 

const loginSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
});

const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState("login");
  const { user, loginMutation, registerMutation } = useAuth();
  const [location, navigate] = useLocation();

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" },
  });

  const registerForm = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      name: "",
      email: "",
    },
  });

  const onLoginSubmit = async (values) => loginMutation.mutate(values);

  const onRegisterSubmit = async (values) => {
    const { confirmPassword, ...userData } = values;
    registerMutation.mutate(userData);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fcfcfc]">
      <div className="flex w-full max-w-4xl shadow-2xl rounded-2xl overflow-hidden bg-white border border-gray-100">
        {/* Left graphic section */}
        <div className="hidden lg:flex lg:w-1/2 flex-col justify-between items-center bg-gradient-to-br from-[#4fc3f7] via-[#2094f3] to-[#fcfcfc] px-10 py-14 relative">
          <img
            src={bannerImg}
            alt="Food Delivery"
            className="mb-10 w-80 h-80 object-contain drop-shadow-2xl animate-fade-in"
            draggable={false}
          />
          <h2 className="text-3xl font-extrabold text-white drop-shadow-lg mb-4 text-center leading-tight">
            Welcome to Smart AI Canteen
          </h2>
          <p className="text-white/90 text-base mb-8 text-center font-medium">
            Order food fast, track in real-time, and get personalised recommendations!
          </p>
          <ul className="space-y-4 text-white/90 text-base">
            <li className="flex items-center">
              <span className="inline-flex items-center justify-center w-7 h-7 mr-3 rounded-full bg-white/80 text-[#2094f3] shadow">
                <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="14 5 8 11 5 8"></polyline>
                </svg>
              </span>
              Fast delivery & real-time tracking
            </li>
            <li className="flex items-center">
              <span className="inline-flex items-center justify-center w-7 h-7 mr-3 rounded-full bg-white/80 text-[#2094f3] shadow">
                <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="14 5 8 11 5 8"></polyline>
                </svg>
              </span>
              Personalized AI-powered menu
            </li>
            <li className="flex items-center">
              <span className="inline-flex items-center justify-center w-7 h-7 mr-3 rounded-full bg-white/80 text-[#2094f3] shadow">
                <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="14 5 8 11 5 8"></polyline>
                </svg>
              </span>
              Secure one-tap login & orders
            </li>
          </ul>
        </div>
        {/* Right Auth section */}
        <div className="flex flex-col justify-center items-center w-full lg:w-1/2 px-6 sm:px-10 py-12">
          <Card className="w-full max-w-sm shadow-none border-0 bg-white">
            <CardHeader className="text-center space-y-2">
              <img
                src={logImg}
                alt="SmartCanteen Logo"
                style={{
                  width: "50%",
                  height: "80px",
                  objectFit: "contain",
                  marginLeft: "auto",
                  marginRight: "auto",
                  marginBottom: "0.5rem",
                  display: "block",
                  position: "relative",
                  bottom: "70px",
                  left: "5px",
                }}
              />
              <CardTitle className="text-2xl font-bold text-[#2094f3] mb-1">
                {activeTab === "login" ? "Login" : "Create your account"}
              </CardTitle>
              <div className="text-gray-400 text-sm">
                {activeTab === "login"
                  ? "Login to order your favourite meals instantly."
                  : "Sign up and start your smart food journey!"}
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-50 rounded-full border border-gray-200">
                  <TabsTrigger value="login" className="rounded-full text-base font-semibold transition-all duration-300 hover:bg-[#2094f3] hover:text-white data-[state=active]:bg-[#2094f3] data-[state=active]:text-white">
                    Login
                  </TabsTrigger>
                  <TabsTrigger value="register" className="rounded-full text-base font-semibold transition-all duration-300 hover:bg-[#2094f3] hover:text-white data-[state=active]:bg-[#2094f3] data-[state=active]:text-white">
                    Register
                  </TabsTrigger>
                </TabsList>
                {/* Login Tab */}
                <TabsContent value="login" className="animate-fade-in">
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Username</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="johndoe"
                                autoComplete="username"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                autoComplete="current-password"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="submit"
                        className="w-full bg-[#2094f3] hover:bg-[#176dc2] transition-all duration-300 rounded-lg py-3 text-base font-bold"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? "Logging in..." : "Login"}
                      </Button>
                    </form>
                  </Form>
                  <div className="mt-4 text-center text-xs">
                    <Link href="/forgot-password">
                      <span className="text-[#2094f3] hover:underline cursor-pointer">Forgot password?</span>
                    </Link>
                  </div>
                </TabsContent>
                {/* Register Tab */}
                <TabsContent value="register" className="animate-fade-in">
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-6">
                      <FormField
                        control={registerForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Full Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="John Doe"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Email</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="john@example.com"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Username</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="johndoe"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-semibold text-gray-700">Confirm Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="rounded-lg border-gray-200 focus:ring-[#2094f3] focus:border-[#2094f3]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="submit"
                        className="w-full bg-[#2094f3] hover:bg-[#176dc2] transition-all duration-300 rounded-lg py-3 text-base font-bold"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                      </Button>
                    </form>
                  </Form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}