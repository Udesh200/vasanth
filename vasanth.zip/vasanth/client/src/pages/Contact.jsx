import React, { useState } from "react";
import "./contact.css";
import logImg from "@/asset/images/log.jpg"; 


export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSuccess(true);
    setForm({ name: "", email: "", message: "" });
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <div className="swiggy-contact-root">
      <div className="swiggy-contact-card">
        <div className="swiggy-contact-left">
          <img
           src={logImg}           
          alt="Canteen Logo"
            className="swiggy-contact-logo"
          />
          <div className="swiggy-contact-info">
            <h2>Smart AI Canteen</h2>
            <p>
              <strong>Location:</strong> Your Campus, Madurai, Tamil Nadu
            </p>
            <p>
              <strong>Phone:</strong> +91 9876543210
            </p>
            <p>
              <strong>Email:</strong> info@smartcanteen.com
            </p>
            <p>
              <strong>Hours:</strong> 8:00 AM – 8:00 PM (Mon-Sat)
            </p>
            <p>
              <strong>Order Support:</strong> orders@smartcanteen.com
            </p>
          </div>
        </div>
        <div className="swiggy-contact-right">
          <h1>Contact Us</h1>
          <p>
            Have a question or suggestion? Fill out the form and we’ll respond soon!
          </p>
          <form className="swiggy-contact-form" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="name">Name</label>
              <input
                required
                id="name"
                name="name"
                type="text"
                value={form.name}
                onChange={handleChange}
                placeholder="Your Name"
                autoComplete="off"
              />
            </div>
            <div>
              <label htmlFor="email">Email</label>
              <input
                required
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
                autoComplete="off"
              />
            </div>
            <div>
              <label htmlFor="message">Message</label>
              <textarea
                required
                id="message"
                name="message"
                value={form.message}
                onChange={handleChange}
                placeholder="How can we help you?"
                rows={4}
              />
            </div>
            <button type="submit" className="swiggy-contact-btn">Send Message</button>
            {success && (
              <div className="swiggy-contact-success">
                Thank you for contacting us! We'll get back to you soon.
              </div>
            )}
          </form>
          <div className="swiggy-contact-footer">
            Or email us at{" "}
            <a href="mailto:info@smartcanteen.com">info@smartcanteen.com</a>
          </div>
        </div>
      </div>
      <div className="swiggy-contact-map">
        <iframe
          title="Canteen Location"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3912.251229625424!2d78.11977537481477!3d9.9252000901857!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00c5843c0c7f7f%3A0x5edd8e004e4d0e8e!2sMadurai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1716535478253!5m2!1sen!2sin"
          width="100%"
          height="250"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </div>
  );
}