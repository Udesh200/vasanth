// server/routes/voiceOrderRoutes.js
import express from 'express';

const router = express.Router();

// Example voice order endpoint
router.post('/', (req, res) => {
  const { audioUrl, userId } = req.body;
  // You can process the voice input here using speech-to-text or AI later
  res.json({
    message: "Voice order received successfully",
    data: {
      audioUrl,
      userId,
    },
  });
});

export default router;
