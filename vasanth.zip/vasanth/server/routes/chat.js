import express from "express";
import OpenAI from "openai";
const router = express.Router();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

router.post("/", async (req, res) => {
  const { message = "" } = req.body;

  if (!message) {
    return res.status(400).json({ reply: "Please provide a message." });
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: message }],
    });
    const reply = completion.choices[0].message.content.trim();
    res.status(201).json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ reply: "Sorry, I couldn't process your request right now." });
  }
});

export default router;