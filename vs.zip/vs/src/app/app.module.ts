import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

// Import your routing module here
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';

// Import your components
import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { BookingsComponent } from './bookings/bookings.component';
import { SupportComponent } from './support/support.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SearchComponent,
    BookingsComponent,
    SupportComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule  // <-- Import your routing module here
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
